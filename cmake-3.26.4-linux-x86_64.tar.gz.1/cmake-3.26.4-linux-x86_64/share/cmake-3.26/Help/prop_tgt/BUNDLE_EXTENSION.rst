BUNDLE_EXTENSION
----------------

The file extension used to name a :prop_tgt:`BUNDLE`, a :prop_tgt:`FRAMEWORK`,
or a :prop_tgt:`MACOSX_BUNDLE` target on the macOS and iOS.

The default value is ``bundle``, ``framework``, or ``app`` for the respective
target types.
